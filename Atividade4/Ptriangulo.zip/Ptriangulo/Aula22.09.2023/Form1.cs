﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula22._09._2023
{
    public partial class PTriangulo : Form
    {
        public PTriangulo()
        {
            InitializeComponent();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double Lado1, Lado2, Lado3;
            if (double.TryParse(txtLado1.Text, out Lado1) && double.TryParse(txtLado2.Text, out Lado2) & double.TryParse(txtLado3.Text, out Lado3))
            {
                if (Lado1 < (Lado2 + Lado3) && Lado1 > Math.Abs(Lado2 - Lado3) && Lado2 < (Lado1 + Lado3) && Lado2 > Math.Abs(Lado1 - Lado3) && Lado3 < (Lado1 + Lado2) && Lado3 > Math.Abs(Lado1 - Lado2))
                {
                    if (Lado1 == Lado2 && Lado2 == Lado3)
                        MessageBox.Show($"Os valores {Lado1}, {Lado2} e {Lado3} formam um triângulo equilátero!");
                    else
                        if (Lado1 != Lado2 && Lado2 != Lado3)
                        MessageBox.Show($"Os valores {Lado1}, {Lado2} e {Lado3} formam um triângulo escaleno!");
                        else
                        MessageBox.Show($"Os valores {Lado1}, {Lado2} e {Lado3} formam um triângulo isósceles!");
                }
                else
                    MessageBox.Show("Esses valores não formam um triângulo!");
            }
        }

        private void TxtLado1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLado1, "");
            double Lado1;
            if (!double.TryParse(txtLado1.Text, out Lado1))
            {
                errorProvider1.SetError(txtLado1, "Valor inválido!");
            }
        }

        private void TxtLado2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtLado2, "");
            double Lado2;
            if (!double.TryParse(txtLado2.Text, out Lado2))
            {
                errorProvider2.SetError(txtLado2, "Valor inválido!");
            }
        }

        private void TxtLado3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtLado3, "");
            double Lado3;
            if (!double.TryParse(txtLado3.Text, out Lado3))
            {
                errorProvider3.SetError(txtLado3, "Valor inválido");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
