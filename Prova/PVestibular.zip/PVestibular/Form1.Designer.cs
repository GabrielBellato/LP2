﻿namespace PVestibular
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnReceberDados = new System.Windows.Forms.Button();
            this.rchtxtSaida = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(257, 281);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(259, 99);
            this.btnLimpar.TabIndex = 0;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnReceberDados
            // 
            this.btnReceberDados.Location = new System.Drawing.Point(257, 139);
            this.btnReceberDados.Name = "btnReceberDados";
            this.btnReceberDados.Size = new System.Drawing.Size(259, 99);
            this.btnReceberDados.TabIndex = 1;
            this.btnReceberDados.Text = "Receber dados";
            this.btnReceberDados.UseVisualStyleBackColor = true;
            this.btnReceberDados.Click += new System.EventHandler(this.BtnReceberDados_Click);
            // 
            // rchtxtSaida
            // 
            this.rchtxtSaida.Location = new System.Drawing.Point(705, 108);
            this.rchtxtSaida.Name = "rchtxtSaida";
            this.rchtxtSaida.ReadOnly = true;
            this.rchtxtSaida.Size = new System.Drawing.Size(372, 413);
            this.rchtxtSaida.TabIndex = 2;
            this.rchtxtSaida.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1389, 632);
            this.Controls.Add(this.rchtxtSaida);
            this.Controls.Add(this.btnReceberDados);
            this.Controls.Add(this.btnLimpar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnReceberDados;
        private System.Windows.Forms.RichTextBox rchtxtSaida;
    }
}

