﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] vetorAlunos = new int[3, 4];
            string auxiliar = "";
            string saida = "";
            int TotalCurso;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Entre com o número de alunos para o curso {i + 1} para o ano {j + 1}", "Entrada de dados");
                    // fechando caso deixe em branco
                    if (auxiliar == "")
                        return;
                    if (!int.TryParse(auxiliar, out vetorAlunos[i, j]))
                    {
                        MessageBox.Show("O valor deve ser um número inteiro!");
                        j--;
                    }
                    else
                    if (vetorAlunos[i,j] < 0)
                    {
                        MessageBox.Show("Número deve ser maior que zero!");
                        j--;
                    }
                    else
                    {
                       
                        saida += "Total do curso " + (i+1)  + " ano " + (j+1) + ": " + vetorAlunos[i, j] + "\n";
                        
                    }
                    if (j == 3)
                    {
                        TotalCurso = vetorAlunos[i, 0] + vetorAlunos[i, 1] + vetorAlunos[i, 2] + vetorAlunos[i, 3];   
                        saida += "Total geral do curso " + (i+1) + ": " + TotalCurso + "\n";
                        
                    }
                }
            }
            rchtxtSaida.Text = saida;
            
           
        }

        private void LbxImprime_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            rchtxtSaida.Clear();
        }
    }
}
