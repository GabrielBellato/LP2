﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnNumericos_Click(object sender, EventArgs e)
        {
            int totalNum = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                    totalNum++;
            }
            MessageBox.Show($"A frase possui {totalNum} números");
            //MessageBox.Show("A frase possui "+totalNum+" números");
        }

        private void BtnPosicaoBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show($"O primeiro caracter em branco ocupa a {posicao} posição");
            {

            }
        }

        private void BtnTotalLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach (var c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"A palavra possui {contador} caracteres que são letras");
        }
    }
}
