﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSortear_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;
            if (!int.TryParse(txtNumero1.Text, out num1) || !int.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Insira dados válidos (números)!");
            } 
            else
            {
                if (num1 <= 0 || num2 <= 0 || num1 >= num2)
                {
                    MessageBox.Show("Os números devem ser diferentes de zero, e o primeiro ser menor que o segundo!");
                }
                else
                {
                    Random objR = new Random();
                    int aleatorio = objR.Next(num1, num2);
                    MessageBox.Show($"O numero sorteado foi: {aleatorio}");
                }
            }
        }
    }
}
