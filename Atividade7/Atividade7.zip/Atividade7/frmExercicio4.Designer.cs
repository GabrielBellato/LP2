﻿namespace Atividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnNumericos = new System.Windows.Forms.Button();
            this.lblTexto = new System.Windows.Forms.Label();
            this.btnPosicaoBranco = new System.Windows.Forms.Button();
            this.btnTotalLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(363, 199);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(704, 96);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnNumericos
            // 
            this.btnNumericos.Location = new System.Drawing.Point(353, 417);
            this.btnNumericos.Name = "btnNumericos";
            this.btnNumericos.Size = new System.Drawing.Size(179, 75);
            this.btnNumericos.TabIndex = 1;
            this.btnNumericos.Text = "Total de números";
            this.btnNumericos.UseVisualStyleBackColor = true;
            this.btnNumericos.Click += new System.EventHandler(this.BtnNumericos_Click);
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(242, 220);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(86, 32);
            this.lblTexto.TabIndex = 2;
            this.lblTexto.Text = "Texto";
            // 
            // btnPosicaoBranco
            // 
            this.btnPosicaoBranco.Location = new System.Drawing.Point(633, 417);
            this.btnPosicaoBranco.Name = "btnPosicaoBranco";
            this.btnPosicaoBranco.Size = new System.Drawing.Size(179, 75);
            this.btnPosicaoBranco.TabIndex = 3;
            this.btnPosicaoBranco.Text = "Posição 1° caracter branco";
            this.btnPosicaoBranco.UseVisualStyleBackColor = true;
            this.btnPosicaoBranco.Click += new System.EventHandler(this.BtnPosicaoBranco_Click);
            // 
            // btnTotalLetras
            // 
            this.btnTotalLetras.Location = new System.Drawing.Point(902, 417);
            this.btnTotalLetras.Name = "btnTotalLetras";
            this.btnTotalLetras.Size = new System.Drawing.Size(179, 75);
            this.btnTotalLetras.TabIndex = 4;
            this.btnTotalLetras.Text = "Total de letras";
            this.btnTotalLetras.UseVisualStyleBackColor = true;
            this.btnTotalLetras.Click += new System.EventHandler(this.BtnTotalLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 666);
            this.Controls.Add(this.btnTotalLetras);
            this.Controls.Add(this.btnPosicaoBranco);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.btnNumericos);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnNumericos;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Button btnPosicaoBranco;
        private System.Windows.Forms.Button btnTotalLetras;
    }
}