﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora1
{
    public partial class Form1 : Form
    {
        double numero1;
        double numero2;
        double resultado;


        public Form1()
        {
            InitializeComponent();
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Primeiro número inválido!");
                txtNum1.Focus();
            }
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Segundo número inválido!");
                txtNum2.Focus();
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
